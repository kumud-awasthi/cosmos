﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CosmosDB
{
    public class Order
    {
        public string id { get; set; }

        public string orderId { get; set; }
        public DateTime creationTime    { get; set; }
    }
}
